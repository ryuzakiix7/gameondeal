import React from 'react';
    import { Routes, Route, Link } from 'react-router-dom';
    import HomePage from './components/HomePage';
    import AdminPanel from './components/AdminPanel';
    import Cart from './components/Cart';

    function App() {
      return (
        <div className="app">
          <nav>
            <div className="container">
              <ul>
                <li><Link to="/">Home</Link></li>
                <li><Link to="/cart">My Cart</Link></li>
                <li><Link to="/admin">Admin</Link></li>
              </ul>
            </div>
          </nav>
          <div className="container">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/admin" element={<AdminPanel />} />
              <Route path="/cart" element={<Cart />} />
            </Routes>
          </div>
        </div>
      );
    }

    export default App;
