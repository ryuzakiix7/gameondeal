import { useState, useEffect } from 'react';
    import localforage from 'localforage';

    export function useLocalforage(key, initialValue) {
      const [value, setValue] = useState(initialValue);

      useEffect(() => {
        const fetchValue = async () => {
          try {
            const storedValue = await localforage.getItem(key);
            if (storedValue !== null) {
              setValue(storedValue);
            }
          } catch (error) {
            console.error('Error fetching data from localforage:', error);
          }
        };

        fetchValue();
      }, [key]);

      useEffect(() => {
        const setItem = async () => {
          try {
            await localforage.setItem(key, value);
          } catch (error) {
            console.error('Error setting data to localforage:', error);
          }
        };

        setItem();
      }, [key, value]);

      return [value, setValue];
    }
