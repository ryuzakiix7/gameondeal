import React, { useState, useEffect } from 'react';
    import { useLocalforage } from '../hooks/useLocalforage';
    import { matchSorter } from 'match-sorter';

    function HomePage() {
      const [games, setGames] = useLocalforage('games', []);
      const [searchQuery, setSearchQuery] = useState('');
      const [filteredGames, setFilteredGames] = useState(games);
      const [platformFilter, setPlatformFilter] = useState('all');
      const [priceRange, setPriceRange] = useState({ min: '', max: '' });
      const [cart, setCart] = useLocalforage('cart', []);

      useEffect(() => {
        let results = games;

        if (searchQuery) {
          results = matchSorter(results, searchQuery, { keys: ['title', 'description'] });
        }

        if (platformFilter !== 'all') {
          results = results.filter(game => game.platform.includes(platformFilter));
        }

        if (priceRange.min !== '' && priceRange.max !== '') {
          results = results.filter(game => game.price >= parseFloat(priceRange.min) && game.price <= parseFloat(priceRange.max));
        } else if (priceRange.min !== '') {
          results = results.filter(game => game.price >= parseFloat(priceRange.min));
        } else if (priceRange.max !== '') {
          results = results.filter(game => game.price <= parseFloat(priceRange.max));
        }

        setFilteredGames(results);
      }, [games, searchQuery, platformFilter, priceRange]);

      const handleBuyNow = (gameTitle) => {
        window.location.href = `https://www.instagram.com/gameondeal?text=I want ${gameTitle}`;
      };

      const handleAddToCart = (game) => {
        setCart([...cart, game]);
      };

      return (
        <div>
          <div className="search-container">
            <div className="search-bar">
              <input
                type="text"
                placeholder="Search games..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <span className="search-icon">
                &#128269;
              </span>
            </div>
          </div>
          <div className="logo-container">
            <span className="controller-logo">🎮</span>
            <h1 className="logo">
              <span>GAME</span>
              <span>ON</span>
              <span>DEAL</span>
            </h1>
          </div>
          <div className="filter-container">
            <label>Platform:</label>
            <select value={platformFilter} onChange={(e) => setPlatformFilter(e.target.value)}>
              <option value="all">All</option>
              <option value="PC">PC</option>
              <option value="PS5">PS5</option>
              <option value="Xbox">Xbox</option>
              <option value="Nintendo Switch">Nintendo Switch</option>
            </select>
            <label>Price Range:</label>
            <input
              type="number"
              placeholder="Min"
              value={priceRange.min}
              onChange={(e) => setPriceRange({ ...priceRange, min: e.target.value })}
            />
            <input
              type="number"
              placeholder="Max"
              value={priceRange.max}
              onChange={(e) => setPriceRange({ ...priceRange, max: e.target.value })}
            />
          </div>
          <div className="game-grid">
            {filteredGames.map((game) => (
              <div key={game.id} className="game-card">
                <img src={game.image} alt={game.title} />
                <div className="game-card-content">
                  <h3>{game.title}</h3>
                  <p>Price: ${game.price}</p>
                  <p>Stock: {game.stock ? 'In Stock' : 'Out of Stock'}</p>
                  <p>Platform: {game.platform.join(', ')}</p>
                  <p>{game.description}</p>
                </div>
                <div className="buy-container">
                  <button className="buy-button" onClick={() => handleBuyNow(game.title)}>Buy Now</button>
                  <span className="cart-icon" onClick={() => handleAddToCart(game)}>&#128722;</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }

    export default HomePage;
