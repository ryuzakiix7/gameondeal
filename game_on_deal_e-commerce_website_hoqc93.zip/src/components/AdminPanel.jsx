import React, { useState, useEffect } from 'react';
    import { useLocalforage } from '../hooks/useLocalforage';

    function AdminPanel() {
      const [pin, setPin] = useState('');
      const [isLoggedIn, setIsLoggedIn] = useState(false);
      const [errorMessage, setErrorMessage] = useState('');
      const [games, setGames] = useLocalforage('games', []);
      const [newGame, setNewGame] = useState({
        id: Date.now(),
        title: '',
        image: '',
        price: '',
        stock: true,
        platform: [],
        description: '',
      });
      const [selectedGame, setSelectedGame] = useState(null);
      const [editMode, setEditMode] = useState(false);

      const handleLogin = () => {
        if (pin === '0277') {
          setIsLoggedIn(true);
          setErrorMessage('');
        } else {
          setErrorMessage('YOU ARE NOT THE ADMIN NI**A');
        }
      };

      const handleLogout = () => {
        setIsLoggedIn(false);
        setPin('');
      };

      const handleInputChange = (e) => {
        const { name, value, type, checked } = e.target;
        if (type === 'checkbox') {
          if (checked) {
            setNewGame({ ...newGame, platform: [...newGame.platform, value] });
          } else {
            setNewGame({ ...newGame, platform: newGame.platform.filter(p => p !== value) });
          }
        } else {
          setNewGame({ ...newGame, [name]: value });
        }
      };

      const handleAddGame = () => {
        setGames([...games, newGame]);
        setNewGame({
          id: Date.now(),
          title: '',
          image: '',
          price: '',
          stock: true,
          platform: [],
          description: '',
        });
      };

      const handleEditGame = (game) => {
        setSelectedGame(game);
        setNewGame({ ...game });
        setEditMode(true);
      };

      const handleUpdateGame = () => {
        const updatedGames = games.map(game => game.id === selectedGame.id ? newGame : game);
        setGames(updatedGames);
        setEditMode(false);
        setSelectedGame(null);
        setNewGame({
          id: Date.now(),
          title: '',
          image: '',
          price: '',
          stock: true,
          platform: [],
          description: '',
        });
      };

      const handleDeleteGame = (gameId) => {
        const updatedGames = games.filter(game => game.id !== gameId);
        setGames(updatedGames);
      };

      const handleStockToggle = (gameId) => {
        const updatedGames = games.map(game =>
          game.id === gameId ? { ...game, stock: !game.stock } : game
        );
        setGames(updatedGames);
      };

      if (!isLoggedIn) {
        return (
          <div className="admin-panel">
            <h2>Admin Login</h2>
            {errorMessage && <p className="error-message">{errorMessage}</p>}
            <input
              type="password"
              placeholder="Enter PIN"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="pin-input"
            />
            <button onClick={handleLogin}>Login</button>
          </div>
        );
      }

      return (
        <div className="admin-panel">
          <h2>Admin Panel</h2>
          <button onClick={handleLogout}>Logout</button>
          <h3>{editMode ? 'Edit Game' : 'Add New Game'}</h3>
          <label>Title:</label>
          <input
            type="text"
            name="title"
            value={newGame.title}
            onChange={handleInputChange}
          />
          <label>Image URL:</label>
          <input
            type="text"
            name="image"
            value={newGame.image}
            onChange={handleInputChange}
          />
          <label>Price:</label>
          <input
            type="number"
            name="price"
            value={newGame.price}
            onChange={handleInputChange}
          />
          <label>Platforms:</label>
          <div className="checkbox-group">
            <label><input type="checkbox" name="platform" value="PC" checked={newGame.platform.includes('PC')} onChange={handleInputChange} /> PC</label>
            <label><input type="checkbox" name="platform" value="PS5" checked={newGame.platform.includes('PS5')} onChange={handleInputChange} /> PS5</label>
            <label><input type="checkbox" name="platform" value="Xbox" checked={newGame.platform.includes('Xbox')} onChange={handleInputChange} /> Xbox</label>
            <label><input type="checkbox" name="platform" value="Nintendo Switch" checked={newGame.platform.includes('Nintendo Switch')} onChange={handleInputChange} /> Nintendo Switch</label>
          </div>
          <label>Description:</label>
          <textarea
            name="description"
            value={newGame.description}
            onChange={handleInputChange}
          />
          {editMode ? (
            <button onClick={handleUpdateGame}>Update Game</button>
          ) : (
            <button onClick={handleAddGame}>Add Game</button>
          )}
          <h3>Game List</h3>
          <div className="game-grid">
            {games.map((game) => (
              <div key={game.id} className="game-card">
                <img src={game.image} alt={game.title} />
                <div className="game-card-content">
                  <h3>{game.title}</h3>
                  <p>Price: ${game.price}</p>
                  <p>Stock: {game.stock ? 'In Stock' : 'Out of Stock'}</p>
                  <p>Platform: {game.platform.join(', ')}</p>
                  <p>{game.description}</p>
                </div>
                <div className="buy-container">
                  <button onClick={() => handleEditGame(game)}>Edit</button>
                  <button onClick={() => handleDeleteGame(game.id)}>Delete</button>
                  <button onClick={() => handleStockToggle(game.id)}>Toggle Stock</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }

    export default AdminPanel;
