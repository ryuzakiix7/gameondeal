import React from 'react';
    import { useLocalforage } from '../hooks/useLocalforage';

    function Cart() {
      const [cart, setCart] = useLocalforage('cart', []);

      const handleRemoveFromCart = (gameId) => {
        const updatedCart = cart.filter(game => game.id !== gameId);
        setCart(updatedCart);
      };

      return (
        <div>
          <h2>My Cart</h2>
          {cart.length === 0 ? (
            <p>Your cart is empty.</p>
          ) : (
            <div className="game-grid">
              {cart.map((game) => (
                <div key={game.id} className="game-card">
                  <img src={game.image} alt={game.title} />
                  <div className="game-card-content">
                    <h3>{game.title}</h3>
                    <p>Price: ${game.price}</p>
                    <p>Platform: {game.platform.join(', ')}</p>
                  </div>
                  <div className="buy-container">
                    <button className="buy-button" onClick={() => handleRemoveFromCart(game.id)}>Remove</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      );
    }

    export default Cart;
